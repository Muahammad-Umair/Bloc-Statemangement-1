# testp

A new Flutter project where i start work on powerfull state-mangement like bloc. 

 In this i just do the simple task with the help of bloc state mangement. I define the event the state and bloc. Also buiild the specific widget rather than the whole ui.
