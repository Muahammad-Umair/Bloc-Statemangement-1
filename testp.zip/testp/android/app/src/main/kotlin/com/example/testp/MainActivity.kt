package com.example.testp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
